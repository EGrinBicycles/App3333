buildscript {
    dependencies {
    }
}
// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id("com.android.application") version "8.2.1" apply false
    id("org.jetbrains.kotlin.android") version "1.8.10" apply false

    //dagger hilt
    id("com.google.dagger.hilt.android") version "2.48" apply false
}